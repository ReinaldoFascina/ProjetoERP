(() => {
  const body = document.body;
  const sidebar = document.getElementById('sidebar');
  const overlay = document.getElementById('menuOverlay');
  const mobileButton = document.getElementById('mobileMenuButton');
  const collapseButton = document.getElementById('collapseMenuButton');
  const storageKey = `sidebar-collapsed-${body.dataset.module || 'default'}`;

  function setMobile(open) {
    sidebar?.classList.toggle('mobile-open', open);
    if (overlay) overlay.hidden = !open;
    mobileButton?.setAttribute('aria-expanded', String(open));
  }

  function setCollapsed(collapsed) {
    body.classList.toggle('sidebar-collapsed', collapsed);
    collapseButton?.setAttribute('aria-expanded', String(!collapsed));
    localStorage.setItem(storageKey, String(collapsed));
  }

  mobileButton?.addEventListener('click', () => setMobile(!sidebar.classList.contains('mobile-open')));
  overlay?.addEventListener('click', () => setMobile(false));
  collapseButton?.addEventListener('click', () => setCollapsed(!body.classList.contains('sidebar-collapsed')));

  document.querySelectorAll('.submenu-toggle').forEach((button) => {
    button.addEventListener('click', () => {
      const group = button.closest('.nav-group');
      const open = !group.classList.contains('open');
      group.classList.toggle('open', open);
      button.setAttribute('aria-expanded', String(open));
    });
  });

  const current = location.pathname;
  let active = null;
  document.querySelectorAll('[data-path]').forEach((link) => {
    const path = link.dataset.path;
    const matches = path === '/' ? current === '/' : current === path || current.startsWith(`${path}/`);
    if (matches && (!active || path.length > active.dataset.path.length)) active = link;
  });
  if (active) {
    active.classList.add('active');
    const group = active.closest('.nav-group');
    group?.classList.add('open');
    group?.querySelector('.submenu-toggle')?.setAttribute('aria-expanded', 'true');
  }
  setCollapsed(localStorage.getItem(storageKey) === 'true');
})();
