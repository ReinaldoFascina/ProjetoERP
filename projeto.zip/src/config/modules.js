export const systemModules = {
  technical: {
    key: 'technical',
    name: 'Gestão de Atendimento Técnico',
    shortName: 'Atendimento Técnico',
    description: 'Chamados, agenda, técnicos, RATs, horas e autorizações do cliente.',
    home: '/',
    roles: ['ADMIN', 'COORDENADOR', 'TECNICO'],
  },
  finance: {
    key: 'finance',
    name: 'Gestão Financeira e Faturamento',
    shortName: 'Financeiro',
    description: 'Movimentos, compras, contas a pagar e receber, caixas e conciliação.',
    home: '/finance',
    roles: ['ADMIN', 'COORDENADOR'],
  }, 
  fiscal: {
    key: 'fiscal',
    name: 'Gestão Fiscal',
    shortName: 'Módulo Fiscal',
    description: 'Declarações, impostos, notas fiscais e relatórios.',
    home: '/fiscal',
    roles: ['ADMIN', 'COORDENADOR'],
  },
};

export function modulesForRole(role) {
  return Object.values(systemModules).filter((module) => module.roles.includes(role));
}
