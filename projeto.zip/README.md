# RESistemas Gestão de Serviços v22

## Instalação
1. Copie `.env.example` para `.env` e ajuste o PostgreSQL.
2. Execute `npm install`.
3. Execute `npm run db:init`.
4. Execute `npm run dev`.

Login inicial: `admin@local.test` / `Admin@123`.

## Recursos
- Chamados, agenda, técnicos, usuários e RATs.
- Cadastro unificado de clientes e fornecedores.
- Itens fiscais de produtos e serviços.
- Faturamento Master-Detail e contas a receber.
- Entrada de compras e contas a pagar.
- Contas/caixas, extrato e estrutura de conciliação.
- Seleção de vários RATs do mesmo cliente para gerar um único movimento, agrupado por item fiscal e valor.
- Preparação de NF-e e NFS-e por movimento.

## Fiscal
A emissão é simulada por padrão. Configure `FISCAL_ENABLED=true` somente após integrar e homologar um provedor fiscal. Produtos geram NF-e e serviços geram NFS-e.
